
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Piscitelli_Federico
 */
public class main {

    public static void main(String args[]) throws Exception {
        //Inizio dichiarazioni variabili
            ArrayList temperature= new ArrayList();  //array che contiene le temperature lette da sensore
            ArrayList umidita= new ArrayList(); //array che contiene l' umidità letta da sensore
            int indexVettori=0;
            serialPortHandler comunicazione=new serialPortHandler(); //creo un nuovo oggetto che comunichi con la seriale
            String letto = null; //variabile lettura da seriale 
        //Fine dichiarazioni variabili
        
            if(comunicazione.connect("COM9","ArduinoSerialIO",9600)){ //se la comunicazione 
                   while(true){
                        letto=comunicazione.readSerial();
                        
                        if(indexVettori<101){
                            Thread.sleep(1000);
                            System.out.println("Aggiunto elemento "+indexVettori);
                            temperature.add(indexVettori,Integer.parseInt(estraiTempUmid(0,letto)));
                            umidita.add(indexVettori,Integer.parseInt(estraiTempUmid(1,letto)));
                            indexVettori++;
                        }
                        else{
                            stampaVettore(temperature,temperature.size());
                            System.out.println("");
                            stampaVettore(umidita,umidita.size());
                            
                            indexVettori=0;
                        }
                        //System.out.println(letto);
                   }
            }
         
    }
    
    static public String estraiTempUmid(int parametro,String daEstrarre){
        String result="";
        //String daEstrarre è del tipo temperatura;umidità;id
        switch(parametro){ //in base al parametro che voglio estrarre
            case 0:{
                result=daEstrarre.substring(0, daEstrarre.indexOf(";")); //estraggo dallo zero al primo punto e virgola
            }
                break;
            case 1:{
                result=daEstrarre.substring(daEstrarre.indexOf(";")+1, daEstrarre.lastIndexOf(";")); //estraggo dal primo punto e virgola all' ultimo punto e virgola
            }
                break;
        }
        
        return result;
    }
    
    static public void stampaVettore(ArrayList vettore,int dimensione){
        for (int i = 0; i < dimensione; i++) {
            System.out.print(vettore.get(i)+"-");
        }
    }
    

}
